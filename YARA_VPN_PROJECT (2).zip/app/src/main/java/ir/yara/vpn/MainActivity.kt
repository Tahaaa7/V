package ir.yara.vpn

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.TrafficStats
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.core.content.ContextCompat
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var store: ConfigStore
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var traffic: TextView
    private lateinit var count: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var pending: YaraConfig? = null
    private var rx0 = 0L
    private var tx0 = 0L
    private var time0 = 0L

    private val qrLauncher = registerForActivityResult(ScanContract()) { result ->
        val value = result.contents?.trim()
        if (!value.isNullOrBlank()) addScanned(value)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ConfigStore(this)
        requestNotificationPermission()
        render()
        startTrafficMonitor()
        startStatusMonitor()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(246, 247, 250))
        }

        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(16, 14, 16, 14)
            background = rounded(Color.WHITE, 20)
        }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBox.addView(TextView(this).apply { text = "یارا VPN"; textSize = 27f; setTextColor(Color.rgb(25,25,30)) })
        titleBox.addView(TextView(this).apply { text = "مدیریت هوشمند سرورها و اتصال VPN"; textSize = 13f; setTextColor(Color.DKGRAY) })
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        val settings = Button(this).apply { text = "⚙"; textSize = 20f }
        header.addView(settings, LinearLayout.LayoutParams(52, 52))
        root.addView(header)

        status = TextView(this).apply { textSize = 16f; setPadding(6, 14, 6, 4) }
        traffic = TextView(this).apply { textSize = 13f; setPadding(6, 2, 6, 10); setTextColor(Color.DKGRAY) }
        root.addView(status); root.addView(traffic)

        val worker = EditText(this).apply { hint = "آدرس Worker"; setText(store.workerUrl()); singleLine = true }
        root.addView(worker)
        val workerRow = LinearLayout(this)
        val saveWorker = Button(this).apply { text = "ذخیره Worker" }
        val refresh = Button(this).apply { text = "↻ دریافت سرورها" }
        workerRow.addView(saveWorker, LinearLayout.LayoutParams(0, -2, 1f)); workerRow.addView(refresh, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(workerRow)
        saveWorker.setOnClickListener { store.setWorkerUrl(worker.text.toString().trim().trimEnd('/')); toast("Worker ذخیره شد") }
        refresh.setOnClickListener {
            val u = worker.text.toString().trim().trimEnd('/')
            if (u.isBlank()) toast("آدرس Worker را وارد کنید") else { store.setWorkerUrl(u); fetchWorker(u) }
        }

        val subscription = EditText(this).apply { hint = "Subscription URL"; setText(store.subscriptionUrl()); singleLine = true }
        root.addView(subscription)
        val subRow = LinearLayout(this)
        val saveSub = Button(this).apply { text = "ذخیره" }
        val updateSub = Button(this).apply { text = "↻ بروزرسانی" }
        subRow.addView(saveSub, LinearLayout.LayoutParams(0, -2, 1f)); subRow.addView(updateSub, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(subRow)
        saveSub.setOnClickListener { store.setSubscriptionUrl(subscription.text.toString().trim()); toast("Subscription ذخیره شد") }
        updateSub.setOnClickListener {
            val u = subscription.text.toString().trim()
            if (u.isBlank()) toast("آدرس Subscription را وارد کنید") else { store.setSubscriptionUrl(u); fetchSubscription(u) }
        }

        val actions = LinearLayout(this)
        val add = Button(this).apply { text = "＋ سرور" }
        val qr = Button(this).apply { text = "▣ QR" }
        val file = Button(this).apply { text = "📄 فایل" }
        val share = Button(this).apply { text = "↗ اشتراک" }
        val stop = Button(this).apply { text = "■ قطع" }
        val internet = Button(this).apply { text = "🌐 تست" }
        listOf(add, qr, file, share, stop, internet).forEach { actions.addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
        root.addView(actions)

        count = TextView(this).apply { textSize = 14f; setPadding(6, 10, 6, 6) }
        root.addView(count)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        redraw()

        settings.setOnClickListener { showSettings() }
        add.setOnClickListener { addManualDialog() }
        qr.setOnClickListener {
            val options = ScanOptions().apply {
                setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                setPrompt("QR کانفیگ یا Subscription را اسکن کنید")
                setBeepEnabled(true); setOrientationLocked(false)
            }
            qrLauncher.launch(options)
        }
        file.setOnClickListener { openConfigFile() }
        share.setOnClickListener { shareConfigs() }
        stop.setOnClickListener { stopVpn() }
        internet.setOnClickListener { testInternet(internet) }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(14, 12, 14, 12)
        background = rounded(Color.WHITE, 18)
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat(); setStroke(1, Color.rgb(225,226,232))
    }

    private fun addManualDialog(prefill: String? = null, existingIndex: Int? = null) {
        val current = existingIndex?.let { store.all().getOrNull(it) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 0, 8, 0) }
        val name = EditText(this).apply { hint = "نام سرور"; setText(current?.name ?: "") }
        val link = EditText(this).apply { hint = "vless:// / vmess:// / trojan:// / ss:// یا JSON"; setText(prefill ?: current?.link ?: ""); minLines = 3; gravity = Gravity.TOP }
        box.addView(name); box.addView(link)
        AlertDialog.Builder(this).setTitle(if (existingIndex == null) "افزودن کانفیگ" else "ویرایش کانفیگ").setView(box)
            .setPositiveButton("ذخیره") { _, _ ->
                val value = link.text.toString().trim()
                if (value.isBlank()) return@setPositiveButton
                try { XrayConfigBuilder.build(value) } catch (e: Exception) { toast("کانفیگ نامعتبر: ${e.message}"); return@setPositiveButton }
                val c = YaraConfig(name.text.toString().ifBlank { "سرور یارا" }, value, current?.source ?: "manual")
                if (existingIndex == null) store.add(c) else store.update(existingIndex, c)
                redraw()
            }.setNegativeButton("لغو", null).show()
    }

    private fun openConfigFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
        }
        startActivityForResult(i, 10)
    }

    private fun importConfigText(text: String) {
        val links = SubscriptionParser.parse(text)
        if (links.isNotEmpty()) {
            links.forEachIndexed { i, link -> store.add(YaraConfig("Imported ${i + 1}", link, "file")) }
            redraw(); toast("${links.size} کانفیگ وارد شد")
            return
        }
        val single = text.trim()
        if (single.isNotBlank()) addManualDialog(single) else toast("فایل خالی است")
    }

    private fun addScanned(value: String) {
        if (value.startsWith("http://", true) || value.startsWith("https://", true)) fetchSubscription(value) else addManualDialog(value)
    }

    private fun fetchWorker(base: String) {
        thread {
            try {
                val conn = URL("$base/api/configs").openConnection() as HttpURLConnection
                conn.connectTimeout = 10000; conn.readTimeout = 15000; conn.requestMethod = "GET"
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val a = JSONObject(body).optJSONArray("configs") ?: error("فرمت Worker نامعتبر است")
                var countAdded = 0
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i); val link = o.optString("link", "").trim()
                    if (link.isNotBlank()) { store.add(YaraConfig(o.optString("name", "Worker ${i + 1}"), link, "worker")); countAdded++ }
                }
                runOnUiThread { redraw(); toast("$countAdded کانفیگ از Worker دریافت شد") }
            } catch (e: Exception) { runOnUiThread { toast("خطای Worker: ${e.message ?: "اتصال ناموفق"}") } }
        }
    }

    private fun fetchSubscription(url: String) {
        thread {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 10000; conn.readTimeout = 20000
                conn.setRequestProperty("User-Agent", "YARA-VPN/3.2.1")
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val links = SubscriptionParser.parse(body)
                if (links.isEmpty()) error("کانفیگی در Subscription پیدا نشد")
                links.forEachIndexed { i, link -> store.add(YaraConfig("Subscription ${i + 1}", link, "subscription")) }
                runOnUiThread { redraw(); toast("${links.size} کانفیگ دریافت شد") }
            } catch (e: Exception) { runOnUiThread { toast("خطای Subscription: ${e.message ?: "دریافت ناموفق"}") } }
        }
    }

    private fun redraw() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val configs = store.all()
        count.text = "${configs.size} سرور ذخیره شده"
        val selected = store.selectedLink()
        configs.forEachIndexed { index, c ->
            val row = card()
            val title = TextView(this).apply {
                text = if (c.link == selected) "✓ ${c.name}" else c.name
                textSize = 18f; setTextColor(if (c.link == selected) Color.rgb(20,100,70) else Color.rgb(30,30,35))
            }
            val meta = TextView(this).apply {
                text = "${c.source}  •  ${ServerUtils.endpointText(c.link)}"
                textSize = 12f; setTextColor(Color.DKGRAY); setPadding(0, 4, 0, 8)
            }
            row.addView(title); row.addView(meta)
            val buttons = LinearLayout(this)
            val connect = Button(this).apply { text = if (c.link == selected) "اتصال مجدد" else "اتصال" }
            val ping = Button(this).apply { text = "تست" }
            val edit = Button(this).apply { text = "ویرایش" }
            val more = Button(this).apply { text = "⋮" }
            listOf(connect, ping, edit, more).forEach { buttons.addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
            row.addView(buttons); list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 5, 0, 5) })

            connect.setOnClickListener { connect(c) }
            ping.setOnClickListener {
                ping.isEnabled = false; ping.text = "…"
                thread {
                    val ms = ServerUtils.tcpPing(c.link)
                    runOnUiThread { ping.isEnabled = true; ping.text = if (ms >= 0) "$ms ms" else "ناموفق" }
                }
            }
            edit.setOnClickListener { addManualDialog(existingIndex = index) }
            more.setOnClickListener { showServerMenu(index, c) }
        }
    }

    private fun showServerMenu(index: Int, c: YaraConfig) {
        AlertDialog.Builder(this).setTitle(c.name)
            .setItems(arrayOf("تغییر نام", "اشتراک‌گذاری", "حذف")) { _, which ->
                when (which) {
                    0 -> renameServer(index, c)
                    1 -> shareText(c.name + "\n" + c.link)
                    2 -> { store.remove(index); redraw(); toast("سرور حذف شد") }
                }
            }.show()
    }

    private fun renameServer(index: Int, c: YaraConfig) {
        val input = EditText(this).apply { setText(c.name); selectAll() }
        AlertDialog.Builder(this).setTitle("تغییر نام").setView(input)
            .setPositiveButton("ذخیره") { _, _ -> store.update(index, c.copy(name = input.text.toString().ifBlank { c.name })); redraw() }
            .setNegativeButton("لغو", null).show()
    }

    private fun shareConfigs() {
        val all = store.all()
        if (all.isEmpty()) { toast("سروری برای اشتراک‌گذاری وجود ندارد"); return }
        shareText(all.joinToString("\n") { it.link })
    }

    private fun shareText(text: String) {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }, "اشتراک‌گذاری با"))
    }

    private fun connect(c: YaraConfig) {
        try { XrayConfigBuilder.build(c.link) } catch (e: Exception) { toast("کانفیگ نامعتبر: ${e.message}"); return }
        store.setSelectedLink(c.link)
        val prepare = VpnService.prepare(this)
        if (prepare != null) { pending = c; startActivityForResult(prepare, 9) } else startVpn(c)
        redraw()
    }

    private fun stopVpn() {
        startService(Intent(this, YaraVpnService::class.java).setAction(YaraVpnService.ACTION_STOP))
        store.setStatus("قطع شد"); status.text = "وضعیت: قطع شد"
    }

    private fun startVpn(c: YaraConfig) {
        val i = Intent(this, YaraVpnService::class.java).setAction(YaraVpnService.ACTION_START).putExtra(YaraVpnService.EXTRA_CONFIG, c.link)
        ContextCompat.startForegroundService(this, i)
        status.text = "وضعیت: در حال اتصال به ${c.name}"
    }


    private fun testInternet(button: Button) {
        button.isEnabled = false
        button.text = "در حال تست…"
        thread {
            val started = System.currentTimeMillis()
            val result = try {
                val conn = URL("https://example.com/").openConnection() as HttpURLConnection
                conn.connectTimeout = 7000
                conn.readTimeout = 7000
                conn.instanceFollowRedirects = true
                conn.requestMethod = "GET"
                val code = conn.responseCode
                conn.disconnect()
                if (code in 200..399) "موفق • ${System.currentTimeMillis() - started} ms" else "HTTP $code"
            } catch (e: Exception) {
                "ناموفق • ${e.message ?: "اتصال برقرار نشد"}"
            }
            runOnUiThread {
                button.isEnabled = true
                button.text = "🌐 تست اینترنت"
                toast(result)
            }
        }
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(10, 0, 10, 0) }
        val mtu = EditText(this).apply { hint = "MTU (1280 تا 9000)"; inputType = 2; setText(store.mtu().toString()) }
        val dns = EditText(this).apply { hint = "DNS، جداشده با کاما"; setText(store.dns()) }
        val ipv6 = CheckBox(this).apply { text = "فعال بودن IPv6"; isChecked = store.ipv6() }
        val full = CheckBox(this).apply { text = "عبور کل ترافیک از VPN"; isChecked = store.fullTunnel() }
        val auto = CheckBox(this).apply { text = "اتصال مجدد خودکار"; isChecked = store.autoReconnect() }
        val apps = Button(this).apply { text = "انتخاب برنامه‌های عبوری (${store.allowedPackages().size})" }
        val systemVpn = Button(this).apply { text = "تنظیمات VPN اندروید" }
        box.addView(mtu); box.addView(dns); box.addView(ipv6); box.addView(full); box.addView(auto); box.addView(apps); box.addView(systemVpn)
        apps.setOnClickListener { showAppSelector(apps) }
        systemVpn.setOnClickListener {
            runCatching { startActivity(Intent(Settings.ACTION_VPN_SETTINGS)) }
                .onFailure { toast("بازکردن تنظیمات VPN ممکن نشد") }
        }
        AlertDialog.Builder(this).setTitle("تنظیمات پیشرفته VPN").setView(box)
            .setPositiveButton("ذخیره") { _, _ ->
                store.setMtu(mtu.text.toString().toIntOrNull() ?: 1500)
                store.setDns(dns.text.toString().trim().ifBlank { "1.1.1.1,8.8.8.8" })
                store.setIpv6(ipv6.isChecked); store.setFullTunnel(full.isChecked); store.setAutoReconnect(auto.isChecked)
                toast("تنظیمات ذخیره شد")
            }.setNegativeButton("لغو", null).show()
    }

    private fun showAppSelector(counter: Button) {
        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 || it.packageName == packageName }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
        val labels = apps.map { pm.getApplicationLabel(it).toString() }.toTypedArray()
        val selected = store.allowedPackages().toMutableSet()
        val checked = BooleanArray(apps.size) { selected.contains(apps[it].packageName) }
        AlertDialog.Builder(this).setTitle("برنامه‌های داخل VPN")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked ->
                val pkg = apps[which].packageName
                if (isChecked) selected.add(pkg) else selected.remove(pkg)
            }
            .setPositiveButton("ذخیره") { _, _ ->
                store.setAllowedPackages(selected)
                counter.text = "انتخاب برنامه‌های عبوری (${selected.size})"
                toast(if (selected.isEmpty()) "حالت تمام‌ترافیک فعال شد" else "${selected.size} برنامه انتخاب شد")
            }.setNegativeButton("لغو", null).show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 9 && resultCode == RESULT_OK) pending?.let { startVpn(it) }
        if (requestCode == 10 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val text = contentResolver.openInputStream(uri)?.use { input ->
                    BufferedReader(InputStreamReader(input)).readText()
                } ?: ""
                importConfigText(text)
            } catch (e: Exception) {
                toast("خواندن فایل ناموفق بود: ${e.message ?: "خطا"}")
            }
        }
    }

    private fun startTrafficMonitor() {
        rx0 = TrafficStats.getUidRxBytes(applicationInfo.uid).coerceAtLeast(0)
        tx0 = TrafficStats.getUidTxBytes(applicationInfo.uid).coerceAtLeast(0)
        time0 = System.currentTimeMillis()
        handler.post(object : Runnable {
            override fun run() {
                val rx = TrafficStats.getUidRxBytes(applicationInfo.uid).coerceAtLeast(0)
                val tx = TrafficStats.getUidTxBytes(applicationInfo.uid).coerceAtLeast(0)
                val dt = ((System.currentTimeMillis() - time0).coerceAtLeast(1)) / 1000.0
                traffic.text = "مصرف برنامه: ${fmt(rx)} ↓ / ${fmt(tx)} ↑   •   سرعت: ${fmtRate((rx-rx0).coerceAtLeast(0)/dt)} ↓ ${fmtRate((tx-tx0).coerceAtLeast(0)/dt)} ↑"
                handler.postDelayed(this, 1000)
            }
        })
    }

    private fun startStatusMonitor() {
        handler.post(object : Runnable {
            override fun run() {
                if (::status.isInitialized) status.text = "وضعیت: ${store.status()}"
                handler.postDelayed(this, 1200)
            }
        })
    }

    private fun fmt(v: Long): String {
        val units = arrayOf("B", "KB", "MB", "GB"); var x = v.toDouble(); var i = 0
        while (x >= 1024 && i < units.lastIndex) { x /= 1024; i++ }
        return "%.1f %s".format(x, units[i])
    }
    private fun fmtRate(bytesPerSec: Double): String = fmt(bytesPerSec.toLong()) + "/s"
    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy() }
}
