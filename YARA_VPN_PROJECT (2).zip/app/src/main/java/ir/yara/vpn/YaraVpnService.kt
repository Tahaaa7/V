package ir.yara.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import androidx.core.app.ServiceCompat
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray

class YaraVpnService : VpnService() {
    companion object {
        const val ACTION_START = "ir.yara.vpn.START"
        const val ACTION_STOP = "ir.yara.vpn.STOP"
        const val EXTRA_CONFIG = "config"
        private const val CHANNEL_ID = "yara_vpn"
        private const val NOTIFICATION_ID = 1001
    }

    private var tun: ParcelFileDescriptor? = null
    private var core: CoreController? = null
    private var lastLink = ""
    private var reconnectAttempt = 0
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopCore()
            handler.removeCallbacksAndMessages(null)
            getSharedPreferences("yara", MODE_PRIVATE).edit().putString("status", "قطع شد").apply()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val link = intent?.getStringExtra(EXTRA_CONFIG)
            ?: getSharedPreferences("yara", MODE_PRIVATE).getString("last_link", "")
            ?: ""
        if (link.isBlank()) return START_NOT_STICKY

        lastLink = link
        getSharedPreferences("yara", MODE_PRIVATE).edit().putString("last_link", link).apply()
        reconnectAttempt = 0
        connect(link)
        return START_STICKY
    }

    private fun connect(link: String) {
        startAsForeground("در حال اتصال…")
        stopCore()
        val prefs = getSharedPreferences("yara", MODE_PRIVATE)
        try {
            val mtu = prefs.getInt("mtu", 1500).coerceIn(1280, 9000)
            val ipv6 = prefs.getBoolean("ipv6", true)
            val fullTunnel = prefs.getBoolean("full_tunnel", true)
            val dnsList = prefs.getString("dns", "1.1.1.1,8.8.8.8")
                ?.split(',')?.map { it.trim() }?.filter { it.isNotBlank() } ?: listOf("1.1.1.1", "8.8.8.8")

            val builder = Builder().setSession("YARA VPN").setMtu(mtu).addAddress("10.8.0.2", 30)
            if (ipv6) builder.addAddress("fd00:8:8::2", 64)
            if (fullTunnel) {
                builder.addRoute("0.0.0.0", 0)
                if (ipv6) builder.addRoute("::", 0)
            } else {
                builder.addRoute("10.0.0.0", 8).addRoute("172.16.0.0", 12).addRoute("192.168.0.0", 16)
            }
            for (dns in dnsList) runCatching { builder.addDnsServer(dns) }

            // If the user selected specific apps, only those apps use this VPN.
            // An empty set keeps the normal full-tunnel behavior.
            val allowed = prefs.getStringSet("allowed_packages", emptySet()) ?: emptySet()
            if (allowed.isNotEmpty()) {
                for (pkg in allowed) {
                    runCatching { builder.addAllowedApplication(pkg) }
                }
            } else {
                // The Xray process runs under the same Android UID as YARA.
                // Excluding our own package prevents Xray's upstream sockets
                // from being routed back into the TUN and creating a loop.
                runCatching { builder.addDisallowedApplication(packageName) }
            }

            tun = builder.establish() ?: error("TUN ساخته نشد")

            val fd = tun!!.fd
            core = Libv2ray.newCoreController(object : CoreCallbackHandler {
                override fun startup(): Int {
                    reconnectAttempt = 0
                    prefs.edit().putString("status", "متصل").apply()
                    startAsForeground("یارا VPN متصل است")
                    return 0
                }
                override fun shutdown(): Int {
                    if (prefs.getBoolean("auto_reconnect", true) && lastLink.isNotBlank()) {
                        prefs.edit().putString("status", "ارتباط قطع شد؛ تلاش مجدد…").apply()
                        scheduleReconnect()
                    }
                    return 0
                }
                override fun onEmitStatus(code: Int, msg: String?): Int {
                    if (!msg.isNullOrBlank()) prefs.edit().putString("status", msg).apply()
                    return 0
                }
            })
            core!!.startLoop(XrayConfigBuilder.build(link), fd)
            prefs.edit().putString("status", "متصل").apply()
        } catch (e: Exception) {
            stopCore()
            prefs.edit().putString("status", "اتصال ناموفق: ${e.message ?: "خطای Xray"}").apply()
            startAsForeground("اتصال ناموفق؛ تلاش مجدد…")
            scheduleReconnect()
        }
    }

    private fun scheduleReconnect() {
        val enabled = getSharedPreferences("yara", MODE_PRIVATE).getBoolean("auto_reconnect", true)
        if (!enabled || lastLink.isBlank()) return
        reconnectAttempt++
        val delay = minOf(30_000L, 2_000L * reconnectAttempt)
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ connect(lastLink) }, delay)
    }

    private fun startAsForeground(text: String) {
        val stopIntent = Intent(this, YaraVpnService::class.java).setAction(ACTION_STOP)
        val pending = PendingIntent.getService(this, 7, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("یارا VPN")
            .setContentText(text)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .addAction(Notification.Action.Builder(null, "قطع اتصال", pending).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, 0)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "YARA VPN", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun stopCore() {
        try { core?.stopLoop() } catch (_: Exception) {}
        core = null
        try { tun?.close() } catch (_: Exception) {}
        tun = null
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopCore()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onRevoke() {
        handler.removeCallbacksAndMessages(null)
        stopCore()
        stopSelf()
        super.onRevoke()
    }

    override fun onBind(intent: Intent?): IBinder? = super.onBind(intent)
}
