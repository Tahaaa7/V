export default {
  async fetch(request) {
    const url = new URL(request.url);
    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization"
    };
    if (request.method === "OPTIONS") return new Response("", {headers:cors});
    if (url.pathname === "/api/configs") {
      // کانفیگ‌های خودت را اینجا اضافه کن.
      const configs = [
        // {name:"Server 1", link:"vless://..."},
        // {name:"Server 2", link:"vmess://..."}
      ];
      return new Response(JSON.stringify({ok:true, configs}), {
        headers: {"Content-Type":"application/json", ...cors}
      });
    }
    return new Response("YARA VPN Worker", {headers:cors});
  }
};
