package ir.yara.vpn

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class ConfigStore(context: Context) {
    private val p = context.getSharedPreferences("yara", Context.MODE_PRIVATE)

    fun all(): MutableList<YaraConfig> {
        val a = JSONArray(p.getString("configs", "[]"))
        val result = mutableListOf<YaraConfig>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            result += YaraConfig(
                o.optString("name", "Server"),
                o.optString("link", ""),
                o.optString("source", "manual")
            )
        }
        return result.filter { it.link.isNotBlank() }.toMutableList()
    }

    fun replace(items: List<YaraConfig>) {
        val a = JSONArray()
        items.forEach { c ->
            a.put(JSONObject().put("name", c.name).put("link", c.link).put("source", c.source))
        }
        p.edit().putString("configs", a.toString()).apply()
    }

    fun add(c: YaraConfig) {
        val items = all()
        val old = items.indexOfFirst { it.link.trim() == c.link.trim() }
        if (old >= 0) items[old] = c else items += c
        replace(items)
    }

    fun update(index: Int, c: YaraConfig) {
        val items = all()
        if (index in items.indices) {
            items[index] = c
            replace(items)
        }
    }

    fun remove(index: Int) {
        val items = all()
        if (index in items.indices) {
            val removed = items.removeAt(index)
            replace(items)
            if (selectedLink() == removed.link) setSelectedLink("")
        }
    }

    fun clear() = p.edit().remove("configs").putString("selected", "").apply()
    fun setWorkerUrl(url: String) = p.edit().putString("worker", url).apply()
    fun workerUrl(): String = p.getString("worker", "") ?: ""
    fun setSubscriptionUrl(url: String) = p.edit().putString("subscription", url).apply()
    fun subscriptionUrl(): String = p.getString("subscription", "") ?: ""
    fun setAutoReconnect(value: Boolean) = p.edit().putBoolean("auto_reconnect", value).apply()
    fun autoReconnect(): Boolean = p.getBoolean("auto_reconnect", true)
    fun setSelectedLink(link: String) = p.edit().putString("selected", link).apply()
    fun selectedLink(): String = p.getString("selected", "") ?: ""

    fun setMtu(value: Int) = p.edit().putInt("mtu", value.coerceIn(1280, 9000)).apply()
    fun mtu(): Int = p.getInt("mtu", 1500)
    fun setDns(value: String) = p.edit().putString("dns", value).apply()
    fun dns(): String = p.getString("dns", "1.1.1.1,8.8.8.8") ?: "1.1.1.1,8.8.8.8"
    fun setIpv6(value: Boolean) = p.edit().putBoolean("ipv6", value).apply()
    fun ipv6(): Boolean = p.getBoolean("ipv6", true)
    fun setFullTunnel(value: Boolean) = p.edit().putBoolean("full_tunnel", value).apply()
    fun fullTunnel(): Boolean = p.getBoolean("full_tunnel", true)

    fun setStatus(value: String) = p.edit().putString("status", value).apply()
    fun status(): String = p.getString("status", "آماده") ?: "آماده"

    fun setAllowedPackages(value: Set<String>) = p.edit().putStringSet("allowed_packages", value).apply()
    fun allowedPackages(): Set<String> = p.getStringSet("allowed_packages", emptySet()) ?: emptySet()
    fun clearAllowedPackages() = p.edit().remove("allowed_packages").apply()
}
