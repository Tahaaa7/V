package ir.yara.vpn

import android.util.Base64
import java.net.InetSocketAddress
import java.net.URI
import java.net.Socket
import java.nio.charset.StandardCharsets
import org.json.JSONObject

object ServerUtils {
    data class Endpoint(val host: String, val port: Int)

    fun endpoint(link: String): Endpoint? {
        val s = link.trim()
        return try {
            if (s.startsWith("vmess://", true)) {
                var b64 = s.substringAfter("vmess://").substringBefore("#").replace("-", "+").replace("_", "/").replace("\\s".toRegex(), "")
                while (b64.length % 4 != 0) b64 += "="
                val json = String(Base64.decode(b64, Base64.DEFAULT), StandardCharsets.UTF_8)
                val o = JSONObject(json)
                val host = o.optString("add")
                val port = o.optInt("port", 443)
                if (host.isBlank()) null else Endpoint(host, port)
            } else if (s.startsWith("ss://", true)) {
                shadowsocksEndpoint(s)
            } else {
                val u = URI(s)
                val host = u.host ?: return null
                val port = if (u.port > 0) u.port else 443
                Endpoint(host, port)
            }
        } catch (_: Exception) { null }
    }

    private fun shadowsocksEndpoint(s: String): Endpoint? {
        val raw = s.removePrefix("ss://").substringBefore("#")
        val at = raw.lastIndexOf('@')
        if (at < 0) return null
        val hostPart = raw.substring(at + 1)
        val split = hostPart.lastIndexOf(':')
        if (split <= 0) return null
        val host = hostPart.substring(0, split).trim('[', ']')
        return Endpoint(host, hostPart.substring(split + 1).toIntOrNull() ?: 443)
    }

    fun tcpPing(link: String, timeoutMs: Int = 4000): Long {
        val ep = endpoint(link) ?: return -1
        val start = System.nanoTime()
        Socket().use { socket ->
            socket.connect(InetSocketAddress(ep.host, ep.port), timeoutMs)
        }
        return (System.nanoTime() - start) / 1_000_000
    }

    fun endpointText(link: String): String = endpoint(link)?.let { "${it.host}:${it.port}" } ?: "Endpoint نامشخص"
}
