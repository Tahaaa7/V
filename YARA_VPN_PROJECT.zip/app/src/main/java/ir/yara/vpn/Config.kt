package ir.yara.vpn

data class YaraConfig(
    val name: String,
    val link: String,
    val source: String = "manual"
)
