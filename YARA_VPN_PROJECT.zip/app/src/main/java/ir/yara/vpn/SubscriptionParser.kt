package ir.yara.vpn

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets

object SubscriptionParser {
    fun parse(text: String): List<String> {
        val raw = text.trim()
        if (raw.isBlank()) return emptyList()
        val candidates = linkedSetOf(raw)
        val normalized = raw.replace("\\s".toRegex(), "")
        for (flags in listOf(Base64.DEFAULT, Base64.URL_SAFE or Base64.NO_WRAP, Base64.URL_SAFE or Base64.DEFAULT)) {
            try {
                val decoded = Base64.decode(normalized, flags).toString(StandardCharsets.UTF_8).trim()
                if (decoded.isNotBlank() && decoded != raw) candidates += decoded
            } catch (_: Exception) { }
        }
        return candidates.flatMap { parseCandidate(it) }.distinct()
    }

    private fun parseCandidate(text: String): List<String> {
        val t = text.trim()
        if (t.startsWith("[")) {
            return try {
                val a = JSONArray(t)
                buildList { for (i in 0 until a.length()) add(a.optString(i)) }.filter(::isLink)
            } catch (_: Exception) { emptyList() }
        }
        if (t.startsWith("{")) {
            return try {
                val o = JSONObject(t)
                val a = o.optJSONArray("configs") ?: o.optJSONArray("links") ?: return emptyList()
                buildList {
                    for (i in 0 until a.length()) {
                        val v = a.opt(i)
                        if (v is JSONObject) add(v.optString("link")) else add(v.toString())
                    }
                }.filter(::isLink)
            } catch (_: Exception) { emptyList() }
        }
        return t.lines().map { it.trim() }
            .filter { it.isNotBlank() && !it.startsWith("#") && isLink(it) }
    }

    private fun isLink(s: String): Boolean {
        val x = s.trim().lowercase()
        return x.startsWith("vless://") || x.startsWith("vmess://") ||
            x.startsWith("trojan://") || x.startsWith("ss://") || x.startsWith("socks://")
    }
}
