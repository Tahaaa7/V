package ir.yara.vpn

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI
import java.net.URLDecoder

object XrayConfigBuilder {
    fun build(link: String): String {
        val s = link.trim()
        return when {
            s.startsWith("vless://", true) -> vless(s)
            s.startsWith("vmess://", true) -> vmess(s)
            s.startsWith("trojan://", true) -> trojan(s)
            s.startsWith("ss://", true) -> shadowsocks(s)
            s.startsWith("{") -> s
            else -> throw IllegalArgumentException("فرمت کانفیگ پشتیبانی نمی‌شود")
        }
    }

    private fun tunInbound() = JSONObject()
        .put("tag", "tun-in")
        .put("protocol", "tun")
        .put("settings", JSONObject()
            .put("mtu", 1500)
            .put("gateway", JSONArray().put("10.8.0.1/30").put("fd00:8:8::1/64")))

    private fun wrap(out: JSONObject): String {
        val root = JSONObject()
        root.put("log", JSONObject().put("loglevel", "warning"))
        root.put("inbounds", JSONArray().put(tunInbound()))
        root.put("outbounds", JSONArray()
            .put(out)
            .put(JSONObject().put("tag", "direct").put("protocol", "freedom"))
            .put(JSONObject().put("tag", "block").put("protocol", "blackhole")))
        root.put("routing", JSONObject()
            .put("domainStrategy", "AsIs")
            .put("rules", JSONArray()))
        root.put("stats", JSONObject())
        return root.toString()
    }

    private fun vless(s: String): String {
        val u = URI(s)
        val q = parseQuery(u.rawQuery ?: "")
        val uuid = u.userInfo ?: throw IllegalArgumentException("UUID وجود ندارد")
        val user = JSONObject().put("id", uuid).put("encryption", q["encryption"] ?: "none")
        q["flow"]?.takeIf { it.isNotBlank() }?.let { user.put("flow", it) }
        val outbound = JSONObject().put("protocol", "vless")
            .put("settings", JSONObject().put("vnext", JSONArray().put(
                JSONObject().put("address", u.host)
                    .put("port", if (u.port > 0) u.port else 443)
                    .put("users", JSONArray().put(user))
            )))
        addStream(outbound, q)
        return wrap(outbound)
    }

    private fun vmess(s: String): String {
        var raw = s.removePrefix("vmess://").trim().replace("-", "+").replace("_", "/")
        while (raw.length % 4 != 0) raw += "="
        val bytes = Base64.decode(raw, Base64.DEFAULT)
        val o = JSONObject(String(bytes, Charsets.UTF_8))
        val user = JSONObject()
            .put("id", o.getString("id"))
            .put("alterId", o.optInt("aid", 0))
            .put("security", o.optString("scy", "auto"))
        val outbound = JSONObject().put("protocol", "vmess")
            .put("settings", JSONObject().put("vnext", JSONArray().put(
                JSONObject().put("address", o.getString("add"))
                    .put("port", parsePort(o.opt("port"), 443))
                    .put("users", JSONArray().put(user))
            )))
        val q = mutableMapOf<String, String>()
        q["type"] = o.optString("net", "tcp")
        q["host"] = o.optString("host", "")
        q["path"] = o.optString("path", "")
        q["security"] = o.optString("tls", "")
        q["sni"] = o.optString("sni", o.optString("host", ""))
        addStream(outbound, q)
        return wrap(outbound)
    }

    private fun trojan(s: String): String {
        val u = URI(s)
        val q = parseQuery(u.rawQuery ?: "")
        val password = u.userInfo ?: throw IllegalArgumentException("رمز Trojan وجود ندارد")
        val outbound = JSONObject().put("protocol", "trojan")
            .put("settings", JSONObject().put("servers", JSONArray().put(
                JSONObject().put("address", u.host)
                    .put("port", if (u.port > 0) u.port else 443)
                    .put("password", password)
            )))
        addStream(outbound, q)
        return wrap(outbound)
    }

    private fun shadowsocks(s: String): String {
        val raw = s.removePrefix("ss://").substringBefore("#")
        val q = parseQuery(URI(s).rawQuery ?: "")
        val at = raw.indexOf('@')
        val userAndHost = if (at >= 0) {
            val userPart = raw.substring(0, at).removePrefix("//")
            val hostPart = raw.substring(at + 1)
            val userInfo = try {
                Base64.decode(userPart, Base64.URL_SAFE or Base64.NO_WRAP).toString(Charsets.UTF_8)
            } catch (_: Exception) { userPart }
            userInfo to hostPart
        } else {
            val decoded = try {
                Base64.decode(raw.removePrefix("//"), Base64.URL_SAFE or Base64.NO_WRAP).toString(Charsets.UTF_8)
            } catch (_: Exception) { "" }
            val splitDecoded = decoded.lastIndexOf('@')
            if (splitDecoded <= 0) throw IllegalArgumentException("Shadowsocks URI نامعتبر است")
            decoded.substring(0, splitDecoded) to decoded.substring(splitDecoded + 1)
        }
        val userInfo = userAndHost.first
        val hostPart = userAndHost.second
        val colon = userInfo.indexOf(':')
        if (colon <= 0) throw IllegalArgumentException("Shadowsocks method/password نامعتبر است")
        val method = userInfo.substring(0, colon)
        val password = userInfo.substring(colon + 1)
        val hp = hostPart.substringBefore("#")
        val split = hp.lastIndexOf(':')
        if (split <= 0) throw IllegalArgumentException("Shadowsocks host/port نامعتبر است")
        val outbound = JSONObject().put("protocol", "shadowsocks")
            .put("settings", JSONObject().put("servers", JSONArray().put(
                JSONObject().put("address", hp.substring(0, split))
                    .put("port", hp.substring(split + 1).toInt())
                    .put("method", method)
                    .put("password", password)
            )))
        return wrap(outbound)
    }

    private fun addStream(out: JSONObject, q: Map<String, String>) {
        val network = q["type"] ?: q["network"] ?: "tcp"
        val stream = JSONObject().put("network", network)
        when (q["security"]?.lowercase()) {
            "tls" -> {
                stream.put("security", "tls")
                val tls = JSONObject()
                q["sni"]?.takeIf { it.isNotBlank() }?.let { tls.put("serverName", it) }
                q["alpn"]?.takeIf { it.isNotBlank() }?.let { tls.put("alpn", JSONArray(it.split(",").map(String::trim))) }
                q["fp"]?.takeIf { it.isNotBlank() }?.let { tls.put("fingerprint", it) }
                tls.put("allowInsecure", q["allowInsecure"] == "1" || q["allowInsecure"] == "true")
                stream.put("tlsSettings", tls)
            }
            "reality" -> {
                stream.put("security", "reality")
                val reality = JSONObject()
                q["sni"]?.takeIf { it.isNotBlank() }?.let { reality.put("serverName", it) }
                q["pbk"]?.takeIf { it.isNotBlank() }?.let { reality.put("publicKey", it) }
                q["sid"]?.takeIf { it.isNotBlank() }?.let { reality.put("shortId", it) }
                q["fp"]?.takeIf { it.isNotBlank() }?.let { reality.put("fingerprint", it) }
                q["spx"]?.takeIf { it.isNotBlank() }?.let { reality.put("spiderX", it) }
                stream.put("realitySettings", reality)
            }
        }
        when (network.lowercase()) {
            "ws" -> {
                val ws = JSONObject().put("path", q["path"] ?: "/")
                q["host"]?.takeIf { it.isNotBlank() }?.let { ws.put("headers", JSONObject().put("Host", it)) }
                stream.put("wsSettings", ws)
            }
            "grpc" -> stream.put("grpcSettings", JSONObject().put("serviceName", q["serviceName"] ?: q["path"] ?: ""))
        }
        out.put("streamSettings", stream)
    }

    private fun parsePort(value: Any?, fallback: Int): Int = value?.toString()?.toIntOrNull() ?: fallback

    private fun parseQuery(raw: String): Map<String, String> {
        if (raw.isEmpty()) return emptyMap()
        return raw.split('&').mapNotNull {
            val p = it.split('=', limit = 2)
            if (p[0].isBlank()) null else p[0] to URLDecoder.decode(p.getOrElse(1) { "" }, "UTF-8")
        }.toMap()
    }
}
