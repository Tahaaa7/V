#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

rm -rf .xray-build
mkdir -p .xray-build app/libs

git clone --depth 1 https://github.com/2dust/AndroidLibXrayLite.git .xray-build/AndroidLibXrayLite
cd .xray-build/AndroidLibXrayLite

go mod tidy
gomobile bind \
  -v \
  -androidapi 24 \
  -target android/arm64,android/amd64,android/arm \
  -trimpath \
  -ldflags="-s -w -buildid= -checklinkname=0" \
  .

find . -maxdepth 1 -type f -name "*.aar" -print -exec cp {} "$ROOT/app/libs/libv2ray.aar" \;

test -s "$ROOT/app/libs/libv2ray.aar"
echo "Created $ROOT/app/libs/libv2ray.aar"
