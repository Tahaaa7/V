#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

test -f "$ROOT/app/src/main/AndroidManifest.xml"
test -f "$ROOT/app/src/main/java/ir/yara/vpn/YaraVpnService.kt"
test -f "$ROOT/app/src/main/java/ir/yara/vpn/MainActivity.kt"
grep -q 'android.permission.BIND_VPN_SERVICE' "$ROOT/app/src/main/AndroidManifest.xml"
grep -q 'foregroundServiceType="specialUse"' "$ROOT/app/src/main/AndroidManifest.xml"
grep -q 'startLoop' "$ROOT/app/src/main/java/ir/yara/vpn/YaraVpnService.kt"
grep -q 'addRoute("0.0.0.0", 0)' "$ROOT/app/src/main/java/ir/yara/vpn/YaraVpnService.kt"
grep -q 'ScanContract' "$ROOT/app/src/main/java/ir/yara/vpn/MainActivity.kt"
grep -q 'SubscriptionParser' "$ROOT/app/src/main/java/ir/yara/vpn/MainActivity.kt"
echo "YARA project static validation: OK"

if grep -R -nE 'prefs\.setStatus\(' app/src/main/java >/dev/null 2>&1; then
  echo "ERROR: SharedPreferences.setStatus misuse remains" >&2
  exit 1
fi
if ! grep -q 'addDisallowedApplication(packageName)' app/src/main/java/ir/yara/vpn/YaraVpnService.kt; then
  echo "ERROR: VPN self-loop protection is missing" >&2
  exit 1
fi
