# YARA VPN — One Click APK

## ساخت APK فقط با GitHub

1. یک Repository خالی در GitHub بساز.
2. فایل‌های داخل این پروژه را داخل Repository آپلود کن.
3. به تب **Actions** برو.
4. Workflow با نام **Build YARA APK** را باز کن.
5. روی **Run workflow** بزن.
6. بعد از اتمام Build، وارد همان اجرای Workflow شو.
7. در بخش **Artifacts** روی `YARA-VPN-debug` بزن.
8. ZIP خروجی را دانلود و APK داخل آن را روی گوشی نصب کن.

Workflow خودش:
- Java 17
- Go
- Android SDK
- Android NDK
- gomobile
- AndroidLibXrayLite
- libv2ray.aar
- Gradle
را آماده می‌کند و APK را می‌سازد.

> برای Build نهایی اینترنت GitHub Actions لازم است تا AndroidLibXrayLite دریافت شود.
