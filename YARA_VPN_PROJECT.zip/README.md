# YARA VPN 3.2

کلاینت اندرویدی YARA برای مدیریت کانفیگ‌های VLESS / VMess / Trojan / Shadowsocks و اتصال از طریق Android VpnService و Xray.

## امکانات
- رابط فارسی و مدیریت چند سرور
- افزودن دستی URI یا JSON
- اسکن QR برای کانفیگ و Subscription
- Subscription URL با پشتیبانی Base64 / متن خط‌به‌خط / JSON
- Worker URL با endpoint `/api/configs`
- ویرایش، تغییرنام، حذف و اشتراک‌گذاری سرورها
- تست TCP endpoint و نمایش latency تقریبی
- انتخاب سرور و اتصال/قطع
- Auto-Reconnect با backoff
- نمایش تقریبی مصرف و سرعت UID برنامه
- تنظیمات MTU، DNS، IPv6 و Full Tunnel
- انتخاب برنامه‌ها برای عبور از VPN (Per-App VPN)
- واردکردن کانفیگ از فایل متنی/JSON/Subscription
- دسترسی سریع به تنظیمات VPN اندروید برای Always-on / Block connections without VPN
- Foreground VPN notification
- ساخت AAR هسته Xray و APK از طریق GitHub Actions

## ساخت
پروژه به `app/libs/libv2ray.aar` نیاز دارد. Workflow گیت‌هاب ابتدا AndroidLibXrayLite را با gomobile می‌سازد و سپس APK را build می‌کند.

AndroidLibXrayLite در نسخه فعلی `CoreController.StartLoop(configContent, tunFd)` و متغیر `xray.tun.fd` را ارائه می‌کند.

## نکته فنی مهم
اتصال مستقیم Android TUN به TUN داخلی Xray به نسخه هسته و تنظیمات socket/routing وابسته است. در پروژه‌های واقعی مثل v2rayNG، تونل VPN و هسته Xray معمولاً با اجزای تکمیلی مدیریت می‌شوند؛ بنابراین پس از ساخت APK باید روی دستگاه واقعی با یک کانفیگ سالم تست شود. این پروژه در این محیط APK نهایی را روی دستگاه اجرا نکرده است.

## Build محلی
1. Android SDK و JDK نصب باشد.
2. Go و gomobile نصب باشند.
3. `scripts/build-xray-android.sh` را اجرا کنید.
4. پروژه را با Android Studio باز و APK را build کنید.

## Worker نمونه
فایل `worker/worker.js` یک endpoint ساده `/api/configs` ارائه می‌دهد.


## v3.2.1 validation fixes

- Fixed a compile-time error where `SharedPreferences.setStatus()` was called even though that method does not exist.
- Added Android VPN self-loop protection by excluding the YARA package from its own full-tunnel VPN.
- Added an IPv6 address to the Android TUN when IPv6 is enabled and matched it with the Xray TUN gateway.
- Static validation now checks for the self-loop protection and the removed `setStatus()` misuse.

The current AndroidLibXrayLite API exposes `StartLoop(configContent, tunFd)` and the `xray.tun.fd` environment variable; Xray's current TUN documentation says Android/iOS receive the TUN FD from the external app through `XRAY_TUN_FD`.
